## DiscordBans-Bot 
[![Build Status](https://travis-ci.org/SSederberg/DiscordBans-Bot.svg?branch=master)](https://travis-ci.org/SSederberg/DiscordBans-Bot)

[Website Front-end](https://github.com/SSederberg/DiscordBans-Web)

Documentation coming soon...
